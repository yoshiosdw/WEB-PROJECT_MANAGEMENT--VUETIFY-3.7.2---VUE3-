<script setup>
</script>
<template>
  <VRow>
    <VCol cols="12">
      <VCardText>
        <p>chart</p>
      </VCardText>
    </VCol>
  </VRow>
</template>

<route lang="yaml">
meta:
  action: Read
  subject: Organization
  redirectIfLoggedIn: false
</route>
