<script setup>
</script>
<template>
  <div>
    item
  </div>
</template>

<route lang="yaml">
  meta:
    subject: Dashboard
    action: Read
    redirectIfLoggedIn: false
</route>