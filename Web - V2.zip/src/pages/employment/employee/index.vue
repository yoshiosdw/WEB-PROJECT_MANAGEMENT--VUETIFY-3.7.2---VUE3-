<script setup>
</script>
<template>
  <div>
    <p>Sample Page</p>
  </div>
</template>
<route lang="yaml">
  meta:
    action: 'Read'
    subject: 'Dashboard'
    redirectIfLoggedIn: false
</route>