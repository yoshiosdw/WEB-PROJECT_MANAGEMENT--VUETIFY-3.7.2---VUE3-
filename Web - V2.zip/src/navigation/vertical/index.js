import barcode from './barcode'
import generalAffair from './general-affair'
import ict from './ict'
import lidahbuaya from './lidahbuaya'
import manufacture from './manufacture'
import qccss from './qccss'
import salesmarketing from './salesmarketing'

export default [...barcode, ...qccss, ...generalAffair, ...salesmarketing, ...manufacture, ...lidahbuaya, ...ict]
