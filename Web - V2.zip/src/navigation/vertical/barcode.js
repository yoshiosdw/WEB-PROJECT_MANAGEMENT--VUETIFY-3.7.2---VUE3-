export default [
  {
    heading: 'Barcode Generator',
    subject:'Barcode',
    action:'Read',
  },
  {
    title: 'Cetak Barcode',
    icon: { icon: 'tabler:barcode' },
    subject:'Barcode',
    action:'Read',
    to: 'barcode',
  },
]
  