export default [
  {
    heading: 'Support',
    subject:'Ticket',
    action:'Read',
  },
  {
    title: 'Ticket',
    icon: { icon: 'tabler:flag' },
    subject:'Ticket',
    action:'Read',
    to: 'ticket-add',
  },
]
